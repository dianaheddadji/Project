﻿<!DOCTYPE html>
<html>
	<head>

		<meta charset="utf-8" />
		<link rel="stylesheet" href="../CSS2/style2.css" />
		<title>Mon CV</title>

	</head>


	<body>

		<h1><?php echo htmlspecialchars($_POST['nom']);?> <?php echo $_POST['prenom'];?></h1>
			<p>
			<img src="../CSS2/icone2.png" alt= "Photo d'identité" title="Photo d'identité" /></a><figcaption>Photo d'identité</figcaption> 
			</p>
			<span id="coordonees">
				<h4>Coordonnées</h4>
				<p>Date de naissance :
				<?php echo htmlspecialchars($_POST['date']);?></p>
				<p>Mail : <?php echo htmlspecialchars($_POST['messagerie']);?></p>
				<p>Téléphone : <?php echo htmlspecialchars($_POST['telephone']);?></p>
				<p>Adresse : <?php echo htmlspecialchars($_POST['adresse']);?></p>
				<p>Code Postale : <?php echo htmlspecialchars($_POST['code']);?></p>
				<p>Contrat : <?php echo htmlspecialchars($_POST['contrat']);?></p>
				
			
		</span>
	
		<div class="conteneur">
		<h2 id="Monexperience">Mon expérience</h2><br />
			<div>
				<p><?php echo htmlspecialchars($_POST['Formulaire']);?></p>
				<p><?php echo htmlspecialchars($_POST['experience']);?></p>
				<p><?php echo htmlspecialchars($_POST['Formulaire2']);?></p>
				<p><?php echo htmlspecialchars($_POST['experience2']);?></p>
				<p><?php echo htmlspecialchars($_POST['Formulaire3']);?></p>
				<p><?php echo htmlspecialchars($_POST['experience3']);?></p>
			</div>
			

		<h2 id="Mescompetences">Mes compétences</h2><br />
			<div>
				<p>
					<strong>Logiciel(s) Utilisé(s) :</strong><br />
					<?php echo htmlspecialchars($_POST['Formulaire4']);?> / 
					<?php echo htmlspecialchars($_POST['autre']);?>
					(<?php echo htmlspecialchars($_POST['level']);?>)
				</p>

				<p>
					<strong>Langue(s) :</strong><br />
					<?php echo htmlspecialchars($_POST['Formulaire5']);?>
					<?php echo htmlspecialchars($_POST['autre2']);?>
					(<?php echo htmlspecialchars($_POST['level2']);?>)<br />
				<p>	
					<strong>Centre(s) d'intéret :</strong><br />
					<?php echo htmlspecialchars($_POST['voyages']);?> /
					<?php echo htmlspecialchars($_POST['Formulaire6']);?>
				</p>
			</div>
	 
		<h2 id="Maformation">Ma formation</h2><br />
			<div>
				<p><?php echo htmlspecialchars($_POST['Formulaire7']);?></p>
				<p><?php echo htmlspecialchars($_POST['formation']);?></p>
				<p><?php echo htmlspecialchars($_POST['Formulaire8']);?></p>
				<p><?php echo htmlspecialchars($_POST['formation2']);?></p>
				<p><?php echo htmlspecialchars($_POST['Formulaire9']);?></p>
				<p><?php echo htmlspecialchars($_POST['formation3']);?></p>
			</div>
		</div>
<span class="convert"><a href="../18973/dompdf/convert.php">Version PDF</a></span>
	</body>		
</html>