<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <!-- Je Configurer la page en Responsive Design -->
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
        <!-- IE peut lire la page web -->
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Accueil | Créer ton CV</title>
        <!-- Liens vers les fichier .css -->
        <link rel="stylesheet" href="../CSS/fichier.css" />
        <link rel="stylesheet" href="../CSS/font-awesome-4.7.0/font-awesome-4.7.0/css/font-awesome.css" />
    </head>


    <body>
        <p id="Haut" class="page">
            <a href="#bas" title="Down" class="fa fa-arrow-down" aria-hidden="true"></a>
        </p>
        <header class="slider2">
            <div class="slides">
                <div class="slide"><img src="../CSS/images/entre1.jpg" alt="" /></div>
                <div class="slide"><img src="../CSS/images/entre2.jpg" alt="" /></div>
                <div class="slide"><img src="../CSS/images/entre3.jpg" alt="" /></div>
                <div class="slide"><img src="../CSS/images/entre4.jpg" alt="" /></div>
                <div class="slide"><img src="../CSS/images/entre5.jpg" alt="" /></div>
                <div class="slide"><img src="../CSS/images/entre6.jpg" alt="" /></div>
                <div class="slide"><img src="../CSS/images/entre7.jpg" alt="" /></div>
            </div>

            <nav>
                <ul id="test">
                <!-- Recherche -->
                    <form method="post" action="traitement.php">
                        <p>
                            <li class="none">Home</li>
                           <!--
                           <label for="pseudo">
                                <span class="fa-phone-square" aria-hidden="true"></span>
                            </label>
                            <input type="text" name="pseudo" id="pseudo" placeholder="Recherche..." size="20" maxlength="10" title="Search"/>
                            -->
                        </p>
                    </form>
                    <li class="none"><a href="../HTML/page1.html" title="À propos">À propos</a></li>
                    <li class="none"><a href="../HTML/page02.html" title="Créer mon CV">Créer votre CV</a></li>
                </ul>
            </nav>
        </header>
        

        <section>
            <div id="conteneur">  
            <article>                
                <h1>Présentation<hr></h1>
               
                <div id="conteneur">
                    <p class="citation">" Laissez parler votre imagination "</p>
                </div>
               

                <div class="slider">
                    <div class="slides">
                    <div class="slide"><img src="../CSS/images/cv.jpg" alt="" /></div>
                    <div class="slide"><img src="../CSS/images/cv02.jpg" alt="" /></div>
                    <div class="slide"><img src="../CSS/images/cv03.jpg" alt="" /></div>
                    <div class="slide"><img src="../CSS/images/cv04.jpg" alt="" /></div>
                </div>
            </article>
            </div id="conteneur">
        </section>
        

        <footer>
            <h3> Nous Contacter</h3>

            <div id="menu">
                <ul> 
                    <li class="none">
                    <!-- Glyphicon -->
                        <span class="fa fa-envelope" aria-hidden="true" id="ma">
                            <a href="mailto:heddadjidiana@gmail.com" title="Envoyer un mail" class="contact"> Mail
                            </a>
                        </span>
                    </li>  <br />

                    <li class="none">    
                        <span class="fa fa-facebook-official" aria-hidden="true" id="fa">
                            <a href="https://www.facebook.com" title="Facebook" class="contact"> Facebook</a>
                        </span>
                    </li>  <br /> 
                
                    <li class="none">
                        <span class="fa fa-twitter" aria-hidden="true" id="tw">
                            <a href="https://www.twitter.com" title="Twitter" class="contact"> Twitter</a>
                        </span>
                    </li>  <br />
                </ul> 
                
                <ul>
                    <li class="none"><a href="../HTML/accueil.html" title="Home">Home</a></li><hr>
                    <li class="none"><a href="../HTML/page02.html" title="Créer mon CV">Créer votre CV</a></li><hr>
                    <li class="none"><a href="../HTML/page1.html" title="À propos">À propos</a></li><hr>
                </ul>
                
                <em>Votre commentaire :<br /><br /> <?php echo htmlspecialchars($_POST['commentaire']); ?></em>           
                
            </div> 

            <p id="bas">
                <a href="#Haut" title="Up" class="fa fa-arrow-up" aria-hidden="true"></a>
            </p>

            <hr class="end">
            <p align="center">Copyright - Tous droits réservés<br /></p>
        </footer>    
    </body>
</html>