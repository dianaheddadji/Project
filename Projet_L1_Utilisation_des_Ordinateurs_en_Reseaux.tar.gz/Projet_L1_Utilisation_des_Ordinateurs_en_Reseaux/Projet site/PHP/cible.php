<p> votre commentaire : <?php echo $_POST['ameliorer']; ?> 
!</p>

