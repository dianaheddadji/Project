<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->  
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->  
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->  
<head>
    <title>Responsive Resume/CV Template for Developers</title>
    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Responsive HTML5 Resume/CV Template for Developers">
    <meta name="author" content="Xiaoying Riley at 3rd Wave Media">    
    <link rel="shortcut icon" href="favicon.ico">  
    <link href='https://fonts.googleapis.com/css?family=Roboto:400,500,400italic,300italic,300,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <!-- Global CSS -->
    <link rel="stylesheet" href="assets/plugins/bootstrap/css/bootstrap.min.css">   
    <!-- Plugins CSS -->
    <link rel="stylesheet" href="assets/plugins/font-awesome/css/font-awesome.css">
    
    <!-- Theme CSS -->  
    <link id="theme-style" rel="stylesheet" href="assets/css/styles-4.css">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head> 

<body>
    <div class="wrapper">
        <div class="sidebar-wrapper">
            <div class="profile-container">
                <img class="profile" src="assets/images/icon.png" alt="" />
                <h1 class="name"><?php echo htmlspecialchars($_POST['nom']);?> <?php echo $_POST['prenom'];?></h1>
                <h3 class="tagline"><?php echo htmlspecialchars($_POST['contrat']);?></h3>
            </div><!--//profile-container-->
            
            <div class="contact-container container-block">
                <ul class="list-unstyled contact-list">
                    <li class="email"><i class="fa fa-envelope"></i><a href="mailto: yourname@email.com"><?php echo htmlspecialchars($_POST['messagerie']);?></a></li>
                    <li class="phone"><i class="fa fa-phone"></i><a href="tel:0123 456 789"><?php echo htmlspecialchars($_POST['telephone']);?></a></li>
                    <li class="website"><i class="fa fa-globe"></i><a href="http://themes.3rdwavemedia.com/website-templates/free-responsive-website-template-for-developers/" target="_blank"><?php echo htmlspecialchars($_POST['site']);?></a></li>
                    <li class="linkedin"><i class="fa fa-linkedin"></i><a href="#" target="_blank"><?php echo htmlspecialchars($_POST['linkedin']);?></a></li>
                </ul>
            </div><!--//contact-container-->
            <div class="education-container container-block">
                <h2 class="container-block-title">Formation</h2>
                <div class="item">
                    <h4 class="degree"><?php echo htmlspecialchars($_POST['formation']);?></h4>
                    <h5 class="meta"><?php echo htmlspecialchars($_POST['lieux0']);?></h5>
                    <div class="time"><?php echo htmlspecialchars($_POST['Formulaire7']);?></div>
                </div><!--//item-->
                <div class="item">
                    <h4 class="degree"><?php echo htmlspecialchars($_POST['formation2']);?></h4>
                    <h5 class="meta"><?php echo htmlspecialchars($_POST['lieux00']);?></h5>
                    <div class="time"><?php echo htmlspecialchars($_POST['Formulaire8']);?></div>
                </div><!--//item-->
            </div><!--//education-container-->
            
            <div class="languages-container container-block">
                <h2 class="container-block-title">Langues</h2>
                <ul class="list-unstyled interests-list">
                    <li><?php echo htmlspecialchars($_POST['Formulaire5']);?><span class="lang-desc"> (<?php echo htmlspecialchars($_POST['level1']);?>)</span></li>
                    <li><?php echo htmlspecialchars($_POST['autre2']);?><span class="lang-desc"> (<?php echo htmlspecialchars($_POST['level2']);?>)</span></li>
                </ul>
            </div><!--//interests-->
            
            <div class="interests-container container-block">
                <h2 class="container-block-title">Centre(s) d'intéret</h2>
                <ul class="list-unstyled interests-list">
                    <li><?php echo htmlspecialchars($_POST['voyages']);?></li>
                    <li><?php echo htmlspecialchars($_POST['Formulaire6']);?></li>
                </ul>
            </div><!--//interests-->
            
        </div><!--//sidebar-wrapper-->
        
        <div class="main-wrapper">
            <section class="section experiences-section">
                <h2 class="section-title"><i class="fa fa-briefcase"></i>Experiences</h2>
                
                <div class="item">
                    <div class="meta">
                        <div class="upper-row">
                            <h3 class="job-title"><?php echo htmlspecialchars($_POST['experience']);?></h3>
                            <div class="time"><?php echo htmlspecialchars($_POST['Formulaire']);?></div>
                        </div><!--//upper-row-->
                        <div class="company"><?php echo htmlspecialchars($_POST['lieux1']);?></div>
                    </div><!--//meta-->
                    <div class="details">
                        <p><?php echo htmlspecialchars($_POST['description']);?></p>  
                    </div><!--//details-->
                </div><!--//item-->
                
                <div class="item">
                    <div class="meta">
                        <div class="upper-row">
                            <h3 class="job-title"><?php echo htmlspecialchars($_POST['experience2']);?></h3>
                            <div class="time"><?php echo htmlspecialchars($_POST['Formulaire2']);?></div>
                        </div><!--//upper-row-->
                        <div class="company"><?php echo htmlspecialchars($_POST['lieux2']);?></div>
                    </div><!--//meta-->
                    <div class="details">
                        <p><?php echo htmlspecialchars($_POST['description2']);?></p>  
                        
                    </div><!--//details-->
                </div><!--//item-->
                
                <div class="item">
                    <div class="meta">
                        <div class="upper-row">
                            <h3 class="job-title"><?php echo htmlspecialchars($_POST['experience3']);?></h3>
                            <div class="time"><?php echo htmlspecialchars($_POST['Formulaire3']);?></div>
                        </div><!--//upper-row-->
                        <div class="company"><?php echo htmlspecialchars($_POST['lieux3']);?></div>
                    </div><!--//meta-->
                    <div class="details">
                        <p><?php echo htmlspecialchars($_POST['description3']);?></p>  
                    </div><!--//details-->
                </div><!--//item-->
                
            </section><!--//section-->
            
            <section class="section experiences-section">
                <h2 class="section-title"><i class="fa fa-rocket"></i>Compétences</h2>
                
                <div class="item">
                    <div class="meta">
                        <div class="upper-row">
                            <h3 class="job-title">Logiciel(s) Utilisé(s) :</h3>
                        </div><!--//upper-row-->
                    </div><!--//meta-->
                    <div class="details">
                        <p><?php echo htmlspecialchars($_POST['Formulaire4']);?> (<?php echo htmlspecialchars($_POST['level']);?>)</p>  
                        <p><?php echo htmlspecialchars($_POST['autre']);?> (<?php echo htmlspecialchars($_POST['level0']);?>)</p>
                    </div><!--//details-->
                </div><!--//item-->

                
            </section><!--//section-->
            <section class="section experiences-section">
                <h2 class="section-title"><i class="fa fa-user"></i>Coordonnées</h2>

                <div class="item">
                    <div class="meta">
                        <div class="upper-row">
                            <h3 class="job-title">Né(e) le :</h3>
                        </div><!--//upper-row-->
                    </div><!--//meta-->
                    <div class="details">
                        <p><?php echo htmlspecialchars($_POST['date']);?></p>  
                        <p>à <?php echo htmlspecialchars($_POST['ville']);?></p>
                    </div><!--//details-->
                </div><!--//item-->

                
                <div class="item">
                    <div class="meta">
                        <div class="upper-row">
                            <h3 class="job-title">Adresse :</h3>
                        </div><!--//upper-row-->
                    </div><!--//meta-->
                    <div class="details">
                        <p><?php echo htmlspecialchars($_POST['adresse']);?></p>  
                        <p><?php echo htmlspecialchars($_POST['code']);?></p>
                    </div><!--//details-->
                </div><!--//item-->

                
            </section><!--//section-->
    </div>
 
    <footer class="footer">
        <div class="text-center">
                <!--/* This template is released under the Creative Commons Attribution 3.0 License. Please keep the attribution link below when using for your own project. Thank you for your support. :) If you'd like to use the template without the attribution, you can check out other license options via our website: themes.3rdwavemedia.com */-->
                <small class="copyright">Designed with <i class="fa fa-heart"></i> by <a href="http://themes.3rdwavemedia.com" target="_blank">Xiaoying Riley</a> for developers</small>
        </div><!--//container-->
    </footer><!--//footer-->
 
    <!-- Javascript -->          
    <script type="text/javascript" src="assets/plugins/jquery-1.11.3.min.js"></script>
    <script type="text/javascript" src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>    
    <!-- custom js -->
    <script type="text/javascript" src="assets/js/main.js"></script>            
</body>
</html> 
