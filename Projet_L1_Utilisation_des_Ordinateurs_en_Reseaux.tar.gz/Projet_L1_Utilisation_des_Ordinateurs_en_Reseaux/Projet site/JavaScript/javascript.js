alert('Bienvenue sur la page de Création de CV !');

function testerRadio(radio) {
    for (var i=0; i<radio.length;i++) {
        if (radio[i].checked) {
            alert("sexe = "+radio[i].value)
        }
    }
}

