<?php

require('dompdf/dompdf_config.inc.php');

$dompdf = new DOMPDF();

$filename = 'index.html';

$dompdf->load_html_file($filename);

$dompdf->render();

$dompdf->stream('document.pdf', array('Attachement'=>true));

?>