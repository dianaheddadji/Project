#ifndef MINISHEL_H___
#define MINISHEL_H___

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <assert.h>
#include <string.h>
#define PROMPT "%s@%s$ "

enum{
  MaxLigne = 1024, // longueur max d'une ligne de commandes
  MaxMot = MaxLigne / 2, // nbre max de mot dans la ligne
  MaxDirs = 100, // nbre max de repertoire dans PATH
  MaxPathLength = 512, // longueur max d'un nom de fichier
};

void decouper(char *, char *, char **, int);
void moncd_(char **, char *, int);
int mon_if(char *, char **, char **, int, size_t);
int monexec_(char *, char **);

#endif
