#include "minishel.h"

int main(){
  char * mot[MaxMot];
  char * commandes[MaxMot];
  char * dirs[MaxDirs];
  char * cd = "cd";
  char * dir = "";
  char dirsbis[MaxDirs];
  char ligne[MaxLigne];
  char pathname[MaxPathLength];
  int i, tmp, t=0, c;

	getcwd(dirsbis, sizeof(dirsbis));

  /* Decouper PATH en repertoires */
  decouper(getenv("PATH"), ":", dirs, MaxDirs);

  /* Lire et traiter chaque ligne de commande */
  for(printf(PROMPT, getenv("USER"), dirsbis); fgets(ligne, sizeof ligne, stdin) != 0; printf(PROMPT, getenv("USER"), dirsbis)){
    decouper(ligne, ";", commandes, MaxMot);
	  for(c = 0; commandes[c]; ++c){
      decouper(commandes[c], " \t\n", mot, MaxMot);
  		if(mot[0] == 0)            // ligne vide
    		continue;

			//Exercice 18 Commande Interne 'moncd'
			if(!strcmp(mot[0],cd)){
				moncd_(mot, dir, t);
				getcwd(dirsbis, sizeof(dirsbis));
				continue;
			}

			//Exercice 19 Sortir proprement
			if(!strcmp(mot[0], "exit")){
				printf("Bye\n");
				return 0;
			}

    	tmp = fork();               // lancer le processus enfant
    	if(tmp < 0){
      	perror("fork");
      	continue;
    	}
    	if(tmp != 0){             // parent : attendre la fin de l'enfant
				while(wait(0)!= tmp);
      		continue;
    	}
			//enfant : exec du programme
    	for(i = 0; dirs[i] != 0; i++){
      	snprintf(pathname, sizeof pathname, "%s/%s", dirs[i], mot[0]);
        monexec_(pathname, mot);
    	}
   		// aucun exec n'a fonctionne
   		fprintf(stderr, "%s: not found\n", mot[0]);
   		exit(1);
		}
	}
  return 0;
}
