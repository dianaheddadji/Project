#include "minishel.h"

//Exercice 15 : Simuler &&
//ne reconnait pas les commandes internes moncd et exit
int mon_if(char * pathname, char ** mot, char ** dirs, int i, size_t size){
	if(mot[1]==NULL){
    fprintf(stderr, "to few arguments for : %s\n", mot[0]);
		exit(1);
	}
	else if(!strcmp(mot[1], "true")){
    snprintf(pathname, size, "%s/%s", dirs[i], mot[2]);
    execv(pathname, &mot[2]);
		return 0;
	}
	else if(!strcmp(mot[1], "false"))
		exit(0);
	else{
    snprintf(pathname, size, "%s/%s", dirs[i], mot[1]);
    execv(pathname, &mot[1]);
	}
	return 0;
}
