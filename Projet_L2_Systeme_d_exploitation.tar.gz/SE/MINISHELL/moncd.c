#include "minishel.h"

//Exercice 18 Commande Interne 'moncd'
void moncd_(char ** mot, char * dir, int t){
	if(mot[1]==NULL){
		dir=getenv("HOME");
	 	if(dir==0)
	 		dir="/tmp";
 	}else
		dir=mot[1];
	t=chdir(dir);
	if(t<0){
		perror(dir);
	}
}
