#include "minishel.h"

int monexec_(char pathname[], char * mot[]){
	int i, tmp;

	//Pour mettre une commande en arrière plan
  for(i = 0; mot[i]; ++i){
  	if(strcmp(mot[i], "&") == 0){
      tmp = fork();      
      if(tmp < 0)
        perror("fork");
      if(tmp != 0){
        wait(0);
        exit(1);
      }
      printf("%d\n", getpid());
      execv(pathname, mot);
      exit(1);
    }
  }

  execv(pathname, mot);
  return 0;
}
