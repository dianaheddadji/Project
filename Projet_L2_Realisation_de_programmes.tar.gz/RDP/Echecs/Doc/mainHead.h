#include <stdlib.h>
#include <stdio.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#include <png.h>

/** \file mainHead.h \brief Ici, on va y trouver les prototypes des fonctions principales du jeu
	
*/

#ifndef MAIN_HEAD
#define MAIN_HEAD

#define MAX_TAB_POSS 25

#ifdef __cplusplus
extern "C" {
#endif

	/// Enumération des couleurs pour chaque camps.
  enum couleur{cBLANC,cNOIR};

	/// Enumération des types de pièces.
  enum type {tVIDE,tPION,tTOUR,tFOU,tCAVALIER,tREINE,tROI, tELEPHANT, tFAUCON};

	/// Enumération des différents état d'une case.
  enum joueur {jVIDE,jBLANC,jNOIR};

	/// Structure cases permet d'avoir des informations sur le type de la pièce, qui est dans une case donnée, sa couleur ainsi que le joueur qui l'a mise. 
  struct cases{
    enum couleur couleur;
    enum type type;
    enum joueur joueur;
  };
  typedef struct cases cases;

	/// Structure pos permet d'avoir des informations sur une position donnée grâce aux coordonées.
  struct pos{
    int ligne;
    int colone;
  };
  typedef struct pos pos;

	/// Déclaration du plateau de Jeu à deux dimensions.
  extern cases Echequier[10][10];

	/// Tableau des déplacements autorisés de la pièce séléctionnée.
  extern pos TabPossiblilite[MAX_TAB_POSS];

	/// TourJeux définie à qui est le tour.
  extern enum joueur TourJeux;

	/// Coordonnée X de la pièce selectionnée.
  extern int X_Depart;
	/// Coordonnée Y de la pièce selectionnée.
  extern int Y_Depart;

 	/// Coordonnée X de la case d'arrivée.
  extern int X_Arriver;

 	/// Coordonnée Y de la case d'arrivée.
  extern int Y_Arriver;

 	/// Tableau contenant les textures pour le pion Blanc.
  extern GLuint Blanc[8];

 	/// Tableau contenant les textures pour le pion Noir.
  extern GLuint Noir[8];

	/// Tableau contenant les textures pour les gagnants.
  extern GLuint Win;

 	/// Longueur et Largeur de la fenêtre, et indice de celle-ci pour glut.
  extern int Longueur, Largeur, Window;

	/// Fonction de chargement d'image .png convertie en texture.
  extern GLuint loadTex(char *path);
	/// Fonction d'initialisation de l'Echequier ainsi que les textures.
  extern void inizTab(void);
	/// Fonction d'affichage de l'Echequier.
  extern void afficheEchequier(void);

  extern void keyBoard(unsigned char key, int x, int y);

	///Gestion des événements pour la souris.
  extern void mouse(int button, int state, int x, int y);

	/// Permet de convertir la largeur de la fenêtre en position de 1 a 8 (désormais 10).
  extern int convertionX(int x);

	/// Permet de convertir la longueur de la fenêtre en position de 1 a 8 (désormais 10).
  extern int convertionY(int y);

	/// Permet d'initialiser a -1 le Tableau de possibilités.
  extern void initTabPoss(void);

	/// Met dans le tableau de possibilités la ligne et la colonne.
  extern int remplirTabPoss(const int ligne, const int colone, int *poss_tab);

	/// Fonction permettant d'avoir les coordonnées de la pièce que l'on veut déplacer.
  extern void choixCoordonneDepart(int x, int y);

	/// Fonction chapeau pour calculer les possibilités de toutes les pièces.
  extern void calculPossibilite(void);

	///Fonction qui permet de choisir la position d'arrivée de la pièce.
  extern int choixCoordonneArrive(int x, int y);

	/// Vérifie la validité des coordonnées d'arrivée.
  extern int checkDansTableauPossibilite(int x, int y);


	/// Fonction permettant d'arrêter ou de continuer le jeu (en déplacant les pièces).
  extern void boucleOuFin(void);

#ifdef __cplusplus
}
#endif

#endif
