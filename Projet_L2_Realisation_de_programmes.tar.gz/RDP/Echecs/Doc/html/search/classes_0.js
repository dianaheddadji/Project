var searchData=
[
  ['cases',['cases',['../structcases.html',1,'']]]
];
