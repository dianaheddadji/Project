var searchData=
[
  ['loadtex',['loadTex',['../mainHead_8h.html#ae383f6dc9efbd70218976375d46ef653',1,'loadTex(char *path):&#160;pngLoader.c'],['../pngLoader_8c.html#ae383f6dc9efbd70218976375d46ef653',1,'loadTex(char *path):&#160;pngLoader.c']]]
];
