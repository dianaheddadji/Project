var searchData=
[
  ['init_2ec',['init.c',['../init_8c.html',1,'']]]
];
