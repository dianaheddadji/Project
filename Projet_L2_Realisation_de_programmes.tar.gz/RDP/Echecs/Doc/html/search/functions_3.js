var searchData=
[
  ['inittabposs',['initTabPoss',['../mainHead_8h.html#aeb0ca00fdfd5220d883f891753ba6263',1,'initTabPoss(void):&#160;module.c'],['../module_8c.html#aeb0ca00fdfd5220d883f891753ba6263',1,'initTabPoss(void):&#160;module.c']]],
  ['iniztab',['inizTab',['../init_8c.html#a99f1265a9c09823c684333045c62fa3f',1,'inizTab(void):&#160;init.c'],['../mainHead_8h.html#a99f1265a9c09823c684333045c62fa3f',1,'inizTab(void):&#160;init.c']]]
];
