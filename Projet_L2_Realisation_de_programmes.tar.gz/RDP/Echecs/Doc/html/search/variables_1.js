var searchData=
[
  ['colone',['colone',['../structpos.html#acd28d4f0929bde05c96d977f7646b4f3',1,'pos']]],
  ['couleur',['couleur',['../structcases.html#aef1524d50bace09076b9af080395d9bc',1,'cases']]]
];
