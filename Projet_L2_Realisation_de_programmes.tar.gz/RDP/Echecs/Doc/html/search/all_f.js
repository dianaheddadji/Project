var searchData=
[
  ['x_5farriver',['X_Arriver',['../main_8c.html#a30fb58eef0fd222ef7797a04d4870d80',1,'X_Arriver():&#160;main.c'],['../mainHead_8h.html#a30fb58eef0fd222ef7797a04d4870d80',1,'X_Arriver():&#160;main.c']]],
  ['x_5fdepart',['X_Depart',['../main_8c.html#a0a60eabbbd7c6f1dc018260a14c865d8',1,'X_Depart():&#160;main.c'],['../mainHead_8h.html#a0a60eabbbd7c6f1dc018260a14c865d8',1,'X_Depart():&#160;main.c']]]
];
