var Doc_2init_8c =
[
    [ "inizTab", "Doc_2init_8c.html#a99f1265a9c09823c684333045c62fa3f", null ]
];