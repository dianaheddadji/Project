var annotated_dup =
[
    [ "cases", "structcases.html", "structcases" ],
    [ "pos", "structpos.html", "structpos" ]
];