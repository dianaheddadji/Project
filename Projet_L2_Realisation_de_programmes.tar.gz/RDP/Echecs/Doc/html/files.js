var files =
[
    [ "init.c", "init_8c.html", "init_8c" ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "mainHead.h", "mainHead_8h.html", "mainHead_8h" ],
    [ "module.c", "module_8c.html", "module_8c" ],
    [ "mouvCavalier.c", "mouvCavalier_8c.html", "mouvCavalier_8c" ],
    [ "mouvElephant.c", "mouvElephant_8c.html", "mouvElephant_8c" ],
    [ "mouvFaucon.c", "mouvFaucon_8c.html", "mouvFaucon_8c" ],
    [ "mouvFou.c", "mouvFou_8c.html", "mouvFou_8c" ],
    [ "mouvHead.h", "mouvHead_8h.html", "mouvHead_8h" ],
    [ "mouvPion.c", "mouvPion_8c.html", "mouvPion_8c" ],
    [ "mouvReine.c", "mouvReine_8c.html", "mouvReine_8c" ],
    [ "mouvRoi.c", "mouvRoi_8c.html", "mouvRoi_8c" ],
    [ "mouvTour.c", "mouvTour_8c.html", "mouvTour_8c" ],
    [ "pngLoader.c", "pngLoader_8c.html", "pngLoader_8c" ]
];