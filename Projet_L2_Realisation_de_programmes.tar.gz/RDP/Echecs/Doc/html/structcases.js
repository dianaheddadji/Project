var structcases =
[
    [ "couleur", "structcases.html#aef1524d50bace09076b9af080395d9bc", null ],
    [ "joueur", "structcases.html#aa39d0ef3420b80a0db738eed122762eb", null ],
    [ "type", "structcases.html#a48dd8ffe3d8ede043d9a1ef406f6609f", null ]
];