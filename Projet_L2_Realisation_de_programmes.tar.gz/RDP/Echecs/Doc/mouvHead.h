#ifndef MOUV_HEAD
#define MOUV_HEAD

/** \file mouvHead.h \brief Ce fichier comporte tous les prototypes des fonctions pour chaque mouvement de pièce.
*/

#ifdef __cplusplus
extern "C" {
#endif

	/// Fonction de calculs de possibilités pour la Tour
  extern void mouvTour(void);
	/// Fonction de calculs de possibilités pour le Cavalier
  extern void mouvCavalier(void);
	/// Fonction de calculs de possibilités pour le Fou
  extern void mouvFou(void);
	/// Fonction de calculs de possibilités pour le Pion
  extern void mouvPion(void);
	/// Fonction de calculs de possibilités pour la Reine
  extern void mouvReine(void);
	/// Fonction de calculs de possibilités pour le Roi
  extern void mouvRoi(void);
	/// Fonction de calculs de possibilités pour l'Elephant
  extern void mouvElephant(void);
	/// Fonction de calculs de possibilités pour le Faucon
  extern void mouvFaucon(void);

#ifdef __cplusplus
}
#endif

#endif
