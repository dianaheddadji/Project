#include "mainHead.h"

/** \file init.c \brief Ici, on va y trouver la fonction qui servira à initialiser chaque case de l'echiquier, avec ses attributs : type, joueur, et les deux autres tableaux Blanc et Noir en attribuant pour chacune de leur pièce, l'image correspondante.
	
*/

/** Affichage du terrain avec les coordonnées de chaque pièce et leur image respective **/

void inizTab(void){

  int ligne, colone;
    /** Double boucle "for" qui permet de parcourir le plateau afin qu'il y ait un espace "vide" entre le joueur blanc et le joueur noir. **/
  for(ligne=2;ligne<7;ligne++)
    for(colone=2;colone<7;colone++){
      Echequier[ligne][colone].joueur = jVIDE;
    }
  
  Blanc[0] = loadTex("./ressources/pio.png"); //pion
  Blanc[1] = loadTex("./ressources/tou.png"); //tour
  Blanc[2] = loadTex("./ressources/fou.png"); //fou
  Blanc[3] = loadTex("./ressources/cav.png"); //cavalier
  Blanc[4] = loadTex("./ressources/dam.png"); //dame
  Blanc[5] = loadTex("./ressources/roi.png"); //roi
  Blanc[6] = loadTex("./ressources/elph.png"); //Elephant
  Blanc[7] = loadTex("./ressources/fau.png"); //Faucon
  
  Noir[0] = loadTex("./ressources/pio_.png");
  Noir[1] = loadTex("./ressources/tou_.png");
  Noir[2] = loadTex("./ressources/fou_.png");
  Noir[3] = loadTex("./ressources/cav_.png");
  Noir[4] = loadTex("./ressources/dam_.png");
  Noir[5] = loadTex("./ressources/roi_.png");
  Noir[6] = loadTex("./ressources/elph_.png");
  Noir[7] = loadTex("./ressources/fau_.png");

  // Placement des piece Noires
  Echequier[1][0].type = tPION;
  Echequier[1][1].type = tPION;
  Echequier[1][2].type = tPION;
  Echequier[1][3].type = tPION;
  Echequier[1][4].type = tPION;
  Echequier[1][5].type = tPION;
  Echequier[1][6].type = tPION;
  Echequier[1][7].type = tPION;
  Echequier[1][8].type = tPION;
  Echequier[1][9].type = tPION;
  
  Echequier[0][0].type = tTOUR;
  Echequier[0][1].type = tCAVALIER;
  Echequier[0][2].type = tFOU;
  Echequier[0][3].type = tREINE;
  Echequier[0][4].type = tROI;
  Echequier[0][5].type = tFOU;
  Echequier[0][6].type = tCAVALIER;
  Echequier[0][7].type = tTOUR;
  Echequier[0][8].type = tELEPHANT;
  Echequier[0][9].type = tFAUCON;

  Echequier[1][0].joueur = jNOIR;
  Echequier[1][1].joueur = jNOIR;
  Echequier[1][2].joueur = jNOIR;
  Echequier[1][3].joueur = jNOIR;
  Echequier[1][4].joueur = jNOIR;
  Echequier[1][5].joueur = jNOIR;
  Echequier[1][6].joueur = jNOIR;
  Echequier[1][7].joueur = jNOIR;
  Echequier[1][8].joueur = jNOIR;
  Echequier[1][9].joueur = jNOIR;
  
  Echequier[0][0].joueur = jNOIR;
  Echequier[0][1].joueur = jNOIR;
  Echequier[0][2].joueur = jNOIR;
  Echequier[0][3].joueur = jNOIR;
  Echequier[0][4].joueur = jNOIR;
  Echequier[0][5].joueur = jNOIR;
  Echequier[0][6].joueur = jNOIR;
  Echequier[0][7].joueur = jNOIR;
  Echequier[0][8].joueur = jNOIR;
  Echequier[0][9].joueur = jNOIR;

  // Placement des pieces Blanches
  Echequier[8][0].type = tPION;
  Echequier[8][1].type = tPION;
  Echequier[8][2].type = tPION;
  Echequier[8][3].type = tPION;
  Echequier[8][4].type = tPION;
  Echequier[8][5].type = tPION;
  Echequier[8][6].type = tPION;
  Echequier[8][7].type = tPION;
  Echequier[8][8].type = tPION;
  Echequier[8][9].type = tPION;
  
  Echequier[9][0].type = tTOUR;
  Echequier[9][1].type = tCAVALIER;
  Echequier[9][2].type = tFOU;
  Echequier[9][3].type = tREINE;
  Echequier[9][4].type = tROI;
  Echequier[9][5].type = tFOU;
  Echequier[9][6].type = tCAVALIER;
  Echequier[9][7].type = tTOUR;
  Echequier[9][8].type = tELEPHANT;
  Echequier[9][9].type = tFAUCON;
  
  Echequier[8][0].joueur = jBLANC;
  Echequier[8][1].joueur = jBLANC;
  Echequier[8][2].joueur = jBLANC;
  Echequier[8][3].joueur = jBLANC;
  Echequier[8][4].joueur = jBLANC;
  Echequier[8][5].joueur = jBLANC;
  Echequier[8][6].joueur = jBLANC;
  Echequier[8][7].joueur = jBLANC;
  Echequier[8][8].joueur = jBLANC;
  Echequier[8][9].joueur = jBLANC;
  
  Echequier[9][0].joueur = jBLANC;
  Echequier[9][1].joueur = jBLANC;
  Echequier[9][2].joueur = jBLANC;
  Echequier[9][3].joueur = jBLANC;
  Echequier[9][4].joueur = jBLANC;
  Echequier[9][5].joueur = jBLANC;
  Echequier[9][6].joueur = jBLANC;
  Echequier[9][7].joueur = jBLANC;
  Echequier[9][8].joueur = jBLANC;
  Echequier[9][9].joueur = jBLANC;
}
