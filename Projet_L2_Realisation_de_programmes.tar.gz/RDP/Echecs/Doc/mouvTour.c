#include "mouvHead.h"
#include "mainHead.h"

/** \file mouvTour.c \brief Fichier contenant la fonction qui gère les déplacements pour la tour.
	
*/

void mouvTour(void){

  int i_for;
  int poss_tab = 0;
  
  
  /* on remet a zero toute les possibilite quant la fct est apeller
     pour ne pas garder des  possibilite de cout d'avant
  */ 

  initTabPoss();
  /*
  int i;
  for(i =0; i<15;i++)
    printf("%d-%d\n",TabPossiblilite[i].ligne,TabPossiblilite[i].colone);*/
  
  for(i_for = X_Depart -1;  i_for >= 0;  i_for-- )
    if(!remplirTabPoss(i_for, Y_Depart, &poss_tab))
      break;
  for(i_for = X_Depart +1;  i_for < 10;  i_for++ )
    if(!remplirTabPoss(i_for, Y_Depart, &poss_tab))
      break;
  for(i_for = Y_Depart -1;  i_for >= 0;  i_for-- )
    if(!remplirTabPoss(X_Depart, i_for, &poss_tab))
      break;
  for(i_for = Y_Depart +1;  i_for < 10;  i_for++ )
    if(!remplirTabPoss(X_Depart, i_for, &poss_tab))
      break;
}
