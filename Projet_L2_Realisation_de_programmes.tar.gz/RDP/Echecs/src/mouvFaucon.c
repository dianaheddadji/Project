#include "mouvHead.h"
#include "mainHead.h"


/** mouvFaucon sera un mélange des fonctions mouvCavalier et mouvFou**/

void mouvFaucon(void)
{
	//LA PARTIE CAVALIER
  int poss_tab = 0;

  initTabPoss();
  
  remplirTabPoss(X_Depart - 2 , Y_Depart - 1, &poss_tab);
    
  remplirTabPoss(X_Depart - 2 , Y_Depart + 1, &poss_tab);

  remplirTabPoss(X_Depart + 2 , Y_Depart - 1, &poss_tab);
   
  remplirTabPoss(X_Depart + 2 , Y_Depart + 1, &poss_tab);

  remplirTabPoss(X_Depart - 1 , Y_Depart - 2, &poss_tab);
      
  remplirTabPoss(X_Depart + 1 , Y_Depart - 2, &poss_tab);
      
  remplirTabPoss(X_Depart - 1 , Y_Depart + 2, &poss_tab);

  remplirTabPoss(X_Depart + 1 , Y_Depart + 2, &poss_tab);

	//LA PARTIE FOU

  int i_for, j_for;

  for(i_for=X_Depart-1, j_for=Y_Depart-1;  i_for>=0 && j_for>=0; i_for--, j_for--)
    if(!remplirTabPoss(i_for, j_for, &poss_tab))
      break;
  
  for(i_for=X_Depart-1, j_for=Y_Depart+1;  i_for>=0 && j_for<10; i_for--, j_for++)
    if(!remplirTabPoss(i_for, j_for, &poss_tab))
      break;

  for(i_for=X_Depart+1, j_for=Y_Depart+1;  i_for<10 && j_for<10; i_for++, j_for++)
    if(!remplirTabPoss(i_for, j_for, &poss_tab))
      break;
  
  for(i_for=X_Depart+1, j_for=Y_Depart-1;  i_for<10 && j_for>=0; i_for++, j_for--)
    if(!remplirTabPoss(i_for, j_for, &poss_tab))
      break;
}
