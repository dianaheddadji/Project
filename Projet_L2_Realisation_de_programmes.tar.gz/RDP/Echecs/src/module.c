#include "mainHead.h"
#include "mouvHead.h"


/*! la fonction convertionX prend un paramètre: un x qui va définir la largeur du plateau, ici 8 qu'on a modifié à 10 afin d'agrandir la grille. !*/
int convertionX(int x)
{
  return ((10*x)/Largeur);
}


/*! Comme pour la fonction convertionX, convertionY prend en paramètre un int "y" pour définir la longueur du plateau de jeu qu'on a également modifié. !*/
int convertionY(int y)
{
  return ((10*y)/Longueur);
}

/*! La fonction initTabPoss initialise chaque déplacements autorisés de la pièce selectionnée. On part de i=0 pour arriver au nombre maximale de possibilités. !*/
void initTabPoss(void){
  int i;
  for (i = 0 ; i< MAX_TAB_POSS ; i++){
    TabPossiblilite[i].ligne = -1;
    TabPossiblilite[i].colone = -1;
  }
}

/*! La fonction remplirTabPoss stocke dans poss_tab les coordonnées (ligne+colonne) d'une case correspondant à un déplacement possible pour une pièce donnée. Sa valeur de retour permettra de savoir si oui ou non on a pu stocker les coordonnées. !*/
int remplirTabPoss(const  int ligne, const int colone, int *poss_tab){
  
  if(!(ligne >= 0 && ligne< 10) || !(colone >= 0 && colone < 10))
    return 0;
  if( Echequier[ligne][colone].joueur == TourJeux )
    return 0;
  if( Echequier[ligne][colone].joueur == jVIDE ) {

    TabPossiblilite[*poss_tab].ligne= ligne;
    TabPossiblilite[*poss_tab].colone= colone;
    (*poss_tab)++ ;
    return 1;
  }

  if(Echequier[ligne][colone].joueur != TourJeux){
    TabPossiblilite[*poss_tab].ligne= ligne;
    TabPossiblilite[*poss_tab].colone= colone;
    (*poss_tab)++ ;
    return 0;
  }
  return 0;
}


/*! La fonction choixCoordonneDepart sera utilisée pour tous les déplacements de chaque pièce. Elle permet de "sauvegarder" la position actuelle de la pièce choisie en fonction de ses coordonnées x et y. !*/
void choixCoordonneDepart(int x, int y){
  X_Depart = x;
  Y_Depart = y;
}


/*! calculPossibilite appellera la fonction de déplacement correspondante à la pièce choisie. Pour cela, un switch va répertorier les différents cas en leur attribuant à chacun sa fonction correspondante. Si une information n'est pas répertoriée, un message d'erreur apparaîtra. !*/
void calculPossibilite(void){ 

  switch( Echequier[X_Depart][Y_Depart].type){
  case tPION:
    mouvPion();
    break;
  case tTOUR:
    mouvTour();
    break;   
  case tFOU:
    mouvFou();
    break;
  case tCAVALIER:
    mouvCavalier();
    break;   
  case tREINE:
    mouvReine();
    break;
  case tROI:
    mouvRoi();
    break;
  case tELEPHANT:
    mouvElephant();
    break;
  case tFAUCON:
    mouvFaucon();
    break;
  default:
    printf("ERREUR switch calcul\n");
    break;
  }
}


/*! choixCoordonneArrive est visuellement presque identique à "choixCoordonneDepart", seulement, ici, on va établir une limite pour les déplacements de chaque pièce. Ainsi, on verra que les déplacements autorisés pour une pièce donnée se colorer en vert et non tout le plateau. !*/
int choixCoordonneArrive(int x, int y){
  if(TabPossiblilite[0].ligne == -1 || !checkDansTableauPossibilite(x, y))
    return 0;
  X_Arriver = x;
  Y_Arriver = y;
  return 1;
}


/*! Cette fonction regarde si les valeurs x et y envoyées en paramètre (lors d'un clique à la souris) correspondent aux coordonnées d'une case de déplacements autorisés (c'est-à-dire, une case colorée en vert et cela en fonction de la pièce choisie). Elle renvoie 1 si c'est le cas, 0 sinon. !*/
int checkDansTableauPossibilite(int x, int y){
  int i_for;
  for(i_for = 0;  i_for< MAX_TAB_POSS;  i_for ++)
    if(x == TabPossiblilite[i_for].ligne && y == TabPossiblilite[i_for].colone)
      return 1;
  return 0;
}


/*! La fonction boucleOuFin permet de faire 3 choses: dans un premier temps elle détermine la condition d'arrêt du jeu en fixant un gagnant et un perdant (selon s'il y a echecs et mat). Ensuite elle permet d'actualiser les positions des pièces sur le plateau. Et enfin, elle alterne les joueurs (blanc et noir) à chaque fin de mouvements de l'un ou de l'autre. !*/
void boucleOuFin(void){
  //Condition d'arrêt
  if( Echequier[X_Arriver][Y_Arriver].type == tROI){
    printf("Le joueur %d a gagné!\n", TourJeux);
	if(TourJeux==jBLANC)
       Win = loadTex("./ressources/win1.png"); //Si le joueur blanc gagne
	else
	   Win = loadTex("./ressources/win2.png"); //Si le joueur noir gagne
	TourJeux = jVIDE;
  }
  
  // on copie dans case arriver ce qu'il y a sur case départ
  Echequier[X_Arriver][Y_Arriver].type =  Echequier[X_Depart][Y_Depart].type;
  Echequier[X_Arriver][Y_Arriver].joueur =  Echequier[X_Depart][Y_Depart].joueur;
  // on supprimme ce qu'il y a sur la case départ
  Echequier[X_Depart][Y_Depart].joueur = jVIDE;
  Echequier[X_Depart][Y_Depart].type = jVIDE;
    
  // Change TourJeux passe de blanc à noir ou de noir à blanc
  if(TourJeux != jVIDE)
  {
	if(TourJeux == jBLANC)
	   TourJeux = jNOIR;
	else
       TourJeux = jBLANC;
  }
  X_Depart = -1;
  X_Depart = -1;
}
