#include "mainHead.h"
#include "mouvHead.h"

/** \file main.c hkhkhku \brief hkhkhku 
	
*/

//On fait un echequier de 64 cases la table du jeu repose sur un tableau à deux dimensions
cases Echequier[10][10];
pos TabPossiblilite[MAX_TAB_POSS]; // MAX_TAB_POSS constante déclaré dans mainHead représente le nombre de possibilité qui est de 25
enum joueur TourJeux = jBLANC; // La partie commence initialement par le joueur blanc 


//Initialisation des différents axes abscisse / ordonnée
int X_Depart = 0;
int Y_Depart = 0;

int X_Arriver = 0;
int Y_Arriver = 0;


GLuint Blanc[8];
GLuint Noir[8];
GLuint Win;

//Initialisation de la taille de la fenêtre
int Longueur, Largeur, Window;


/*
	Cette fonction va servir à l'affichage de la fenêtre, on lui envoie rien en paramètre et elle ne retourne rien
	- la gestion de la couleur pour le plateau du jeu
	- 
*/

void statut(float x, float y, int ligne, int colone,  float dimension){
if(Echequier[ligne][colone].type){
	if(Echequier[ligne][colone].joueur == jBLANC)
	  glBindTexture(GL_TEXTURE_2D, Blanc[Echequier[ligne][colone].type-1]);
	else
	  glBindTexture(GL_TEXTURE_2D, Noir[Echequier[ligne][colone].type-1]);
	glBegin(GL_QUADS);
	glTexCoord2f(0.0, 0.0); glVertex3d(y, x, 0.1);
	glTexCoord2f(0.0, 1.0); glVertex3d(y, x-dimension, 0.1);
	glTexCoord2f(1.0, 1.0); glVertex3d(y+dimension, x-dimension, 0.1);
	glTexCoord2f(1.0, 0.0); glVertex3d(y+dimension, x, 0.1);
	glEnd();}}

void afficheEchequier(void){

  int couleur = 1;
  int ligne, colone;
  float x, y;
  static float dimension = (float)2/10;
  static GLfloat cBlanc[] = {1.0f, 1.0f, 1.0f, 1.0f};
  static GLfloat cGris[] = {0.5f, 0.5f, 0.5f, 1.0f};
  static GLfloat cVerte[] = {0.0f, 1.0f, 0.0f, 1.0f};
  
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  glEnable(GL_DEPTH_TEST);
  glEnable(GL_BLEND);
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
  glEnable(GL_TEXTURE_2D);
  
  for(ligne=0;ligne<10;ligne++){
    
    couleur?(couleur=0):(couleur=1);
    x = -(((2*(float)ligne)/10) - 1);
    
    for(colone=0;colone<10;colone++){
      
      couleur?(couleur=0):(couleur=1);
      y = ((2*(float)colone)/10) - 1;
      
      glDisable(GL_TEXTURE_2D);
      if(checkDansTableauPossibilite(ligne, colone))
	glColor4fv(cVerte);
      else
	if(couleur)
	  glColor4fv(cGris);
	else
	  glColor4fv(cBlanc);
      glBegin(GL_QUADS);
      glVertex3d(y, x, 0.2);
      glVertex3d(y, x-dimension, 0.2);
      glVertex3d(y+dimension, x-dimension, 0.2);
      glVertex3d(y+dimension, x, 0.2);
      glEnd();
      
      glEnable(GL_TEXTURE_2D);
      glColor4fv(cBlanc);
    
	//Chaque cas du switch se verra attribuer une pièce du jeu. Ce dernier gèrera le déplacement dans le cas où 

statut(x,  y,  ligne,  colone,   dimension);

      /*switch(Echequier[ligne][colone].type){
      case tVIDE:
	break;
	
      case tPION:
	if(Echequier[ligne][colone].joueur == jBLANC)
	  glBindTexture(GL_TEXTURE_2D, Blanc[Echequier[ligne][colone].type-1]);
	else
	  glBindTexture(GL_TEXTURE_2D, Noir[Echequier[ligne][colone].type-1]);
	glBegin(GL_QUADS);
	glTexCoord2f(0.0, 0.0); glVertex3d(y, x, 0.1);
	glTexCoord2f(0.0, 1.0); glVertex3d(y, x-dimension, 0.1);
	glTexCoord2f(1.0, 1.0); glVertex3d(y+dimension, x-dimension, 0.1);
	glTexCoord2f(1.0, 0.0); glVertex3d(y+dimension, x, 0.1);
	glEnd();
	break;
	
      case tTOUR:
	if(Echequier[ligne][colone].joueur == jBLANC)
	  glBindTexture(GL_TEXTURE_2D, Blanc[Echequier[ligne][colone].type-1]);
	else
	  glBindTexture(GL_TEXTURE_2D, Noir[Echequier[ligne][colone].type-1]);
	glBegin(GL_QUADS);
	glTexCoord2f(0.0, 0.0); glVertex3d(y, x, 0.1);
	glTexCoord2f(0.0, 1.0); glVertex3d(y, x-dimension, 0.1);
	glTexCoord2f(1.0, 1.0); glVertex3d(y+dimension, x-dimension, 0.1);
	glTexCoord2f(1.0, 0.0); glVertex3d(y+dimension, x, 0.1);
	glEnd();
	break;
	
      case tFOU:
	if(Echequier[ligne][colone].joueur == jBLANC)
	  glBindTexture(GL_TEXTURE_2D, Blanc[Echequier[ligne][colone].type-1]);
	else
	  glBindTexture(GL_TEXTURE_2D, Noir[Echequier[ligne][colone].type-1]);
	glBegin(GL_QUADS);
	glTexCoord2f(0.0, 0.0); glVertex3d(y, x, 0.1);
	glTexCoord2f(0.0, 1.0); glVertex3d(y, x-dimension, 0.1);
	glTexCoord2f(1.0, 1.0); glVertex3d(y+dimension, x-dimension, 0.1);
	glTexCoord2f(1.0, 0.0); glVertex3d(y+dimension, x, 0.1);
	glEnd();
	break;
	
      case tCAVALIER:
	if(Echequier[ligne][colone].joueur == jBLANC)
	  glBindTexture(GL_TEXTURE_2D, Blanc[Echequier[ligne][colone].type-1]);
	else
	  glBindTexture(GL_TEXTURE_2D, Noir[Echequier[ligne][colone].type-1]);
	glBegin(GL_QUADS);
	glTexCoord2f(0.0, 0.0); glVertex3d(y, x, 0.1);
	glTexCoord2f(0.0, 1.0); glVertex3d(y, x-dimension, 0.1);
	glTexCoord2f(1.0, 1.0); glVertex3d(y+dimension, x-dimension, 0.1);
	glTexCoord2f(1.0, 0.0); glVertex3d(y+dimension, x, 0.1);
	glEnd();
	break;
	
      case tREINE:
	if(Echequier[ligne][colone].joueur == jBLANC)
	  glBindTexture(GL_TEXTURE_2D, Blanc[Echequier[ligne][colone].type-1]);
	else
	  glBindTexture(GL_TEXTURE_2D, Noir[Echequier[ligne][colone].type-1]);
	glBegin(GL_QUADS);
	glTexCoord2f(0.0, 0.0); glVertex3d(y, x, 0.1);
	glTexCoord2f(0.0, 1.0); glVertex3d(y, x-dimension, 0.1);
	glTexCoord2f(1.0, 1.0); glVertex3d(y+dimension, x-dimension, 0.1);
	glTexCoord2f(1.0, 0.0); glVertex3d(y+dimension, x, 0.1);
	glEnd();
	break;
	
	
      case tROI:
	if(Echequier[ligne][colone].joueur == jBLANC)
	  glBindTexture(GL_TEXTURE_2D, Blanc[Echequier[ligne][colone].type-1]);
	else
	  glBindTexture(GL_TEXTURE_2D, Noir[Echequier[ligne][colone].type-1]);
	glBegin(GL_QUADS);
	glTexCoord2f(0.0, 0.0); glVertex3d(y, x, 0.1);
	glTexCoord2f(0.0, 1.0); glVertex3d(y, x-dimension, 0.1);
	glTexCoord2f(1.0, 1.0); glVertex3d(y+dimension, x-dimension, 0.1);
	glTexCoord2f(1.0, 0.0); glVertex3d(y+dimension, x, 0.1);
	glEnd();
	break;


      case tELEPHANT:
	if(Echequier[ligne][colone].joueur == jBLANC)
	  glBindTexture(GL_TEXTURE_2D, Blanc[Echequier[ligne][colone].type-1]);
	else
	  glBindTexture(GL_TEXTURE_2D, Noir[Echequier[ligne][colone].type-1]);
	glBegin(GL_QUADS);
	glTexCoord2f(0.0, 0.0); glVertex3d(y, x, 0.1);
	glTexCoord2f(0.0, 1.0); glVertex3d(y, x-dimension, 0.1);
	glTexCoord2f(1.0, 1.0); glVertex3d(y+dimension, x-dimension, 0.1);
	glTexCoord2f(1.0, 0.0); glVertex3d(y+dimension, x, 0.1);
	glEnd();
	break;

      case tFAUCON:
	if(Echequier[ligne][colone].joueur == jBLANC)
	  glBindTexture(GL_TEXTURE_2D, Blanc[Echequier[ligne][colone].type-1]);
	else
	  glBindTexture(GL_TEXTURE_2D, Noir[Echequier[ligne][colone].type-1]);
	glBegin(GL_QUADS);
	glTexCoord2f(0.0, 0.0); glVertex3d(y, x, 0.1);
	glTexCoord2f(0.0, 1.0); glVertex3d(y, x-dimension, 0.1);
	glTexCoord2f(1.0, 1.0); glVertex3d(y+dimension, x-dimension, 0.1);
	glTexCoord2f(1.0, 0.0); glVertex3d(y+dimension, x, 0.1);
	glEnd();
	break;
      }*/
    }
  }
  
  if(TourJeux == jVIDE){
    glBindTexture(GL_TEXTURE_2D, Win);
    glBegin(GL_QUADS);
    glTexCoord2f(0.0, 1.0); glVertex3d(-0.75, -0.75, 0);
    glTexCoord2f(1.0, 1.0); glVertex3d(0.75, -0.75, 0);
    glTexCoord2f(1.0, 0.0); glVertex3d(0.75, 0.75, 0);
    glTexCoord2f(0.0, 0.0); glVertex3d(-0.75, 0.75, 0);
    glEnd();
  }
  
  glDisable(GL_TEXTURE_2D);
  glDisable(GL_BLEND);
  glDisable(GL_DEPTH_TEST);
  glFlush();
  
  glutSwapBuffers();
  glutPostRedisplay();
}

void keyBoard(unsigned char key, int x, int y)
{
  (void)x, (void)y;
  switch(key) {
  case 27:
    glutDestroyWindow(Window);
    exit(0);
    break;
  }
  glutPostRedisplay();
}

void mouse(int button, int state, int x, int y)
{
  int choixx, choixy;
  (void)state;
  switch(button){
  case 0:
	if(TourJeux!=jVIDE){
	   choixx=convertionX(y);
       choixy=convertionY(x);
       if(TourJeux==Echequier[choixx][choixy].joueur){
	      choixCoordonneDepart(choixx, choixy);
	      calculPossibilite();
       }
	   else{
	      if(choixCoordonneArrive(choixx, choixy)){
	         boucleOuFin();
	         initTabPoss();
	      }
       }
	}
    break;
  }
  glutPostRedisplay();
}

int main(int argc, char **argv){
  Longueur = 1024;
  Largeur = 768;

  glutInit(&argc, argv);
  glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH);
  glutInitWindowSize(Longueur, Largeur);
  Window = glutCreateWindow("Jeu d'Echecs");
  
  glutDisplayFunc(afficheEchequier);
  glutKeyboardFunc(keyBoard);
  glutMouseFunc(mouse);
  
  inizTab();
  initTabPoss();
    
  glutMainLoop();
  return 0;
}
