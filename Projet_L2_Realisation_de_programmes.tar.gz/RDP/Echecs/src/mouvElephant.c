#include "mouvHead.h"
#include "mainHead.h"

/** mouvElephant sera un mélange des fonctions mouvCavalier et mouvTour**/

void mouvElephant(void)
{
  int poss_tab = 0;

  initTabPoss();
  
  remplirTabPoss(X_Depart - 2 , Y_Depart - 1, &poss_tab);
    
  remplirTabPoss(X_Depart - 2 , Y_Depart + 1, &poss_tab);

  remplirTabPoss(X_Depart + 2 , Y_Depart - 1, &poss_tab);
   
  remplirTabPoss(X_Depart + 2 , Y_Depart + 1, &poss_tab);

  remplirTabPoss(X_Depart - 1 , Y_Depart - 2, &poss_tab);
      
  remplirTabPoss(X_Depart + 1 , Y_Depart - 2, &poss_tab);
      
  remplirTabPoss(X_Depart - 1 , Y_Depart + 2, &poss_tab);

  remplirTabPoss(X_Depart + 1 , Y_Depart + 2, &poss_tab);

  int i_for;
  
  for(i_for = X_Depart -1;  i_for >= 0;  i_for-- )
    if(!remplirTabPoss(i_for, Y_Depart, &poss_tab))
      break;
  for(i_for = X_Depart +1;  i_for < 10;  i_for++ )
    if(!remplirTabPoss(i_for, Y_Depart, &poss_tab))
      break;
  for(i_for = Y_Depart -1;  i_for >= 0;  i_for-- )
    if(!remplirTabPoss(X_Depart, i_for, &poss_tab))
      break;
  for(i_for = Y_Depart +1;  i_for < 10;  i_for++ )
    if(!remplirTabPoss(X_Depart, i_for, &poss_tab))
      break;
}







