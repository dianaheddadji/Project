#include "mouvHead.h"
#include "mainHead.h"

/*! La fonction mouvFou, comme la fonction mouvCavalier, doit prendre en compte la position courante du fou. Suite à ça, à l'aide de deux boucles "for", on teste si, à partir de sa position d'origine, la pièce ira en diagonale droite vers le haut ou à sa symétrie inverse par rapport à cette pièce (c'est-à-dire en diagpnale gauche vers le bas), puis, avec deux autres boucles "for" on fait de même mais avec les symétries opposées par rapport à celles qu'on vient de voir. !*/

void mouvFou(void){

  int i_for, j_for;
  int poss_tab = 0;

  initTabPoss();

  for(i_for=X_Depart-1, j_for=Y_Depart-1;  i_for>=0 && j_for>=0; i_for--, j_for--)
    if(!remplirTabPoss(i_for, j_for, &poss_tab))
      break;
  
  for(i_for=X_Depart-1, j_for=Y_Depart+1;  i_for>=0 && j_for<10; i_for--, j_for++)
    if(!remplirTabPoss(i_for, j_for, &poss_tab))
      break;

  for(i_for=X_Depart+1, j_for=Y_Depart+1;  i_for<10 && j_for<10; i_for++, j_for++)
    if(!remplirTabPoss(i_for, j_for, &poss_tab))
      break;
  
  for(i_for=X_Depart+1, j_for=Y_Depart-1;  i_for<10 && j_for>=0; i_for++, j_for--)
    if(!remplirTabPoss(i_for, j_for, &poss_tab))
      break;
}
