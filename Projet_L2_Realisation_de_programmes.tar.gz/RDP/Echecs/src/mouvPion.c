#include "mouvHead.h"
#include "mainHead.h"

void mouvPion(void)
{
  int i_for, poss_tab = 0;
  initTabPoss();
  if(Echequier[X_Depart][Y_Depart].joueur == jBLANC)
    {
      i_for=X_Depart-1;
      if(Echequier[X_Depart-1][Y_Depart].joueur == 0)//joueurVIDE
	remplirTabPoss(i_for,Y_Depart,&poss_tab);
      if(Y_Depart-1 >= 0)
	if(Echequier[i_for][Y_Depart-1].joueur != TourJeux && Echequier[i_for][Y_Depart-1].joueur != 0)
	  remplirTabPoss(i_for,Y_Depart-1,&poss_tab);
      if(Y_Depart+1 < 10)
	if(Echequier[i_for][Y_Depart+1].joueur != TourJeux && Echequier[i_for][Y_Depart+1].joueur != 0 )
	  remplirTabPoss(i_for,Y_Depart+1,&poss_tab);
      if(X_Depart==8)
	if(Echequier[i_for-1][Y_Depart].joueur == 0 && Echequier[i_for][Y_Depart].joueur == 0)
	  remplirTabPoss(i_for-1,Y_Depart,&poss_tab);
    }
  if(Echequier[X_Depart][Y_Depart].joueur == jNOIR)
    {
      i_for=X_Depart+1;
      if(Echequier[i_for][Y_Depart].joueur == jVIDE)
	remplirTabPoss(i_for,Y_Depart,&poss_tab);
      if(Y_Depart-1 >= 0)
	if(Echequier[i_for][Y_Depart-1].joueur != TourJeux && Echequier[i_for][Y_Depart-1].joueur != 0)
	  remplirTabPoss(i_for,Y_Depart-1,&poss_tab);
      if(Y_Depart+1 < 10)
	if(Echequier[i_for][Y_Depart+1].joueur != TourJeux &&Echequier[i_for][Y_Depart+1].joueur != 0 )
	  remplirTabPoss(i_for,Y_Depart+1,&poss_tab);
      if(X_Depart==1)
	if(Echequier[i_for+1][Y_Depart].joueur == jVIDE && Echequier[i_for][Y_Depart].joueur == jVIDE)
	  remplirTabPoss(i_for+1,Y_Depart,&poss_tab);
    }
}
  








