#include "mainHead.h"

GLuint loadTex(char *path){
  
  GLsizei width, height;
  GLenum format;
  GLint internalFormat;
  GLuint texture;
  GLubyte *data;
  
  png_byte head[8];
  png_structp png_ptr;
  png_infop info_ptr;
  png_uint_32 w, h;
  png_bytep *row_pointers = NULL;
  FILE *fp = NULL;
  int bit_depth, color_type, i;
  
  fp = fopen (path, "rb");
  if (!fp)
    {
      fprintf (stderr, "error: couldn't open \"%s\"!\n", path);
      exit(1);
    }
	
  fread (head, 1, sizeof (head), fp);
  
  if (!png_check_sig (head, sizeof (head)))
    {
      fprintf (stderr, "error: \"%s\" is not a valid PNG image!\n", path);
      fclose (fp);
      exit(1);
    }
	
  png_ptr = png_create_read_struct (PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
  if (!png_ptr)
    {
      fclose (fp);
      exit(1);
    }
	
  info_ptr = png_create_info_struct (png_ptr);
  if (!info_ptr)
    {
      fclose (fp);
      png_destroy_read_struct (&png_ptr, NULL, NULL);
      exit(1);
    }
	
  if (setjmp (png_jmpbuf (png_ptr)))
    {
      fclose (fp);
      png_destroy_read_struct (&png_ptr, &info_ptr, NULL);
      exit(1);
    }

  png_init_io (png_ptr, fp);
  png_set_sig_bytes (png_ptr, sizeof (head));
  png_read_info (png_ptr, info_ptr);
  
  bit_depth = png_get_bit_depth (png_ptr, info_ptr);
  color_type = png_get_color_type (png_ptr, info_ptr);
  
  png_read_update_info (png_ptr, info_ptr);
  png_get_IHDR (png_ptr, info_ptr, &w, &h, &bit_depth, &color_type, NULL, NULL, NULL);
  width = w;
  height = h;
  
  switch (color_type)
    {
    case PNG_COLOR_TYPE_GRAY:
      format = GL_LUMINANCE;
      internalFormat = 1;
      break;

    case PNG_COLOR_TYPE_GRAY_ALPHA:
      format = GL_LUMINANCE_ALPHA;
      internalFormat = 2;
      break;

    case PNG_COLOR_TYPE_RGB:
      format = GL_RGB;
      internalFormat = 3;
      break;

    case PNG_COLOR_TYPE_RGB_ALPHA:
      format = GL_RGBA;
      internalFormat = 4;
      break;

    default:
      fprintf(stderr, "Color error\n");
      exit(1);
    }
	
  data = (GLubyte *)malloc (sizeof (GLubyte) * width * height * internalFormat);
  row_pointers = (png_bytep *)malloc (sizeof (png_bytep) * height);
  
  for (i = 0 ; i < height ; i++)
    row_pointers[i] = (png_bytep)(data + (width * i * internalFormat));
	
  png_read_image (png_ptr, row_pointers);
  png_read_end (png_ptr, NULL);
  png_destroy_read_struct (&png_ptr, &info_ptr, NULL);
  free (row_pointers);
  fclose (fp);
  
  glGenTextures(1, &texture);
  glBindTexture(GL_TEXTURE_2D, texture);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexImage2D(GL_TEXTURE_2D, 0, internalFormat, width, height, 0, format, GL_UNSIGNED_BYTE, data);

  return texture;
}
