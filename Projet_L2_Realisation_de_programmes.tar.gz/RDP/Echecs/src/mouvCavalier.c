#include "mouvHead.h"
#include "mainHead.h"


/*! Cette fonction utilise les coordonnées de départ du cavalier pour former le 'L'sur lequel le cavalier pourra se déplacer. !*/

void mouvCavalier(void){
  int poss_tab = 0;

  initTabPoss();
  
  remplirTabPoss(X_Depart - 2 , Y_Depart - 1, &poss_tab);
    
  remplirTabPoss(X_Depart - 2 , Y_Depart + 1, &poss_tab);

  remplirTabPoss(X_Depart + 2 , Y_Depart - 1, &poss_tab);
   
  remplirTabPoss(X_Depart + 2 , Y_Depart + 1, &poss_tab);

  remplirTabPoss(X_Depart - 1 , Y_Depart - 2, &poss_tab);
      
  remplirTabPoss(X_Depart + 1 , Y_Depart - 2, &poss_tab);
      
  remplirTabPoss(X_Depart - 1 , Y_Depart + 2, &poss_tab);

  remplirTabPoss(X_Depart + 1 , Y_Depart + 2, &poss_tab);

}
