#include "mouvHead.h"
#include "mainHead.h"

/** Deplacement du roi en fonction de sa position de départ X et Y **/
void mouvRoi(void){

  int poss_tab=0;
  
  initTabPoss();

  remplirTabPoss(X_Depart-1, Y_Depart, &poss_tab); /** deplacement de 1 vers la gauche **/
  remplirTabPoss(X_Depart-1, Y_Depart+1, &poss_tab); /** deplacement de 1 en diagonal haut gauche **/
  remplirTabPoss(X_Depart, Y_Depart+1, &poss_tab); /** deplacement de 1 vers le haut **/
  remplirTabPoss(X_Depart+1, Y_Depart+1, &poss_tab); /** deplacement de 1 en diagonal haut droite **/
  remplirTabPoss(X_Depart+1, Y_Depart, &poss_tab); /** deplacement de 1 vers la droite **/
  remplirTabPoss(X_Depart+1, Y_Depart-1, &poss_tab); /** deplacement de 1 en diagonal bas droite **/
  remplirTabPoss(X_Depart, Y_Depart-1, &poss_tab); /** deplacement de 1 vers le bas **/
  remplirTabPoss(X_Depart-1, Y_Depart-1, &poss_tab); /** deplacement de 1 en diagonal bas gauche **/
}
